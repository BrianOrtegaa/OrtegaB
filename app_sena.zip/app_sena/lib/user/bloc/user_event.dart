abstract class UserEvent {}

class LoadUser extends UserEvent {}

class FailUser extends UserEvent {}
