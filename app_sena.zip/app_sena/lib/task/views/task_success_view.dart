import 'package:flutter/material.dart';

class TaskLoadedView extends StatelessWidget {
  final List<String> tasks;

  const TaskLoadedView({super.key, required this.tasks});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: tasks.map((t) => Text(t)).toList(),
    );
  }
}
