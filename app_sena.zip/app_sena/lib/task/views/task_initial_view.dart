import 'package:flutter/material.dart';

class TaskInitialView extends StatelessWidget {
  const TaskInitialView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _innerBox("................"),
          const SizedBox(height: 10),
          _innerBox("..................."),
        ],
      ),
    );
  }

  Widget _innerBox(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 2),
      ),
      child: Text(text),
    );
  }
}
