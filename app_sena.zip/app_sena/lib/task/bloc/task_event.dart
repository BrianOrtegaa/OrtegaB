abstract class TaskEvent {}

class LoadTasks extends TaskEvent {}

class FailTasks extends TaskEvent {}
